<?php
/**
 * @framework       MailTng Framework 
 * @version         1.1
 * @author          MailTng Team
 * @copyright       Copyright (c) 2015 - 2016.	
 * @license		
 * @link	
 */ 
use ma\mailtng\http\Request as Request;
/**
 * @name            actions.php 
 * @description     actions tracking
 * @package         .
 * @category        Native Script
 * @author          MailTng Team			
 */

# to ensure scripts are not called from outside of the framework 
define('MAILTNG_FMW',true);  

# define root folder
$rootPath = trim(dirname(dirname(dirname(__DIR__))));

# require the main configuration of the framework 
require_once $rootPath . '/configs/init.conf.php';

# require request init configurations ( application init and database , cache ... )
require_once $rootPath . '/configs/request.init.conf.php';

# gather parameters
$agent = (count($argv) > 1) ? $argv[1] : null;
$ip = (count($argv) > 2) ? $argv[2] : null;
$language = (count($argv) > 3) ? $argv[3] : null;
$parameters = (count($argv) > 4) ? $argv[4] : null;
$message = (count($argv) > 5) ? $argv[5] : null;

# check if the parameters are exixted
if(isset($agent) && isset($ip) && isset($parameters))
{
    $url = "";
    
    die(Request::sendPostRequest($url, array(
        'api_key' => 'x0ja8s4a3duqk9e2w6vga91hrvi7t14wrdxpv754aql055tr2ee2d59b6hop',
        'func_name' => 'track_actions',
        'agent' => $agent,
        'ip' => $ip,
        'language' => $language,
        'data' => $parameters,
        'message' => $message
    )));
}