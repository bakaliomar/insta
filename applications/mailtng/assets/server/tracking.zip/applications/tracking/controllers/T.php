<?php namespace ma\applications\tracking\controllers
{
    if (!defined('MAILTNG_FMW')) die('<pre>It\'s forbidden to access these files directly , access should be only via index.php </pre>');
    /**
     * @framework       MailTng Framework 
     * @version         1.1
     * @author          MailTng Team
     * @copyright       Copyright (c) 2015 - 2016.	
     * @license		
     * @link	
     */
    use ma\mailtng\application\Controller as Controller;
    use ma\mailtng\files\Paths as Paths;
    use ma\mailtng\globals\Server as Server;
    use ma\mailtng\encryption\Crypto as Crypto;
    use ma\mailtng\types\Arrays as Arrays;
    use ma\mailtng\http\Client as Client;
    use ma\mailtng\http\Request as Request;
    use ma\mailtng\http\Response as Response;
    /**
     * @name            T.controller 
     * @description     The Tracking controller
     * @package		ma\applications\tracking\controllers
     * @category        Controller
     * @author		MailTng Team			
     */
    class T extends Controller 
    {
        /**
         * @name index
         * @description the index action
         */
        public function index() 
        {
            # prevent layout display
            $this->setShowMasterView(false);
            $this->setShowPageView(false);
            
            # get parameters 
            $data = Request::getAllDataFromGET(); 
            
            if(count($data) && key_exists('v',$data))
            { 
                $originalParams = str_replace(' ','+',urldecode($data['v']));
                
                # script file
                $scriptFile = Paths::getCurrentApplicationRealPath() . DS . 'scripts' . DS . 'actions.php';
                
                # get the client 
                $agent = base64_encode(Server::get('HTTP_USER_AGENT'));
                $ip = Client::getIp();
                $language = strtoupper(substr(Server::get('HTTP_ACCEPT_LANGUAGE'), 0, 2));
                
                $parameters = Crypto::AESDecrypt($originalParams);
                
                if(!empty($parameters) && strpos($parameters,'|') > -1)
                {
                    $vars = explode('|',$parameters);
                    
                    if(count($vars))
                    {
                        $type = trim(Arrays::getElement($vars,0));
                        
                        if(in_array($type,array('open','preview','unsub','other')))
                        {
                            # executing the script that handles redirection emails
                            exec("nohup php {$scriptFile} {$agent} {$ip} {$language} {$originalParams} &");
                            
                            if($type != 'open')
                            {
                                $count = count($vars);
                                $link = filter_var($vars[$count-2],FILTER_VALIDATE_URL) ? $vars[$count-2] : $vars[$count-1];
                                $sub = filter_var($vars[$count-2],FILTER_VALIDATE_URL) ? $vars[$count-1] . '=' : 's2=';
                        
                                # remove the link from parameters 
                                unset($vars[count($vars) -1]);
                        
                                if(!empty($link))
                                {
                                    if($type == 'preview')
                                    {
                                        # change type to lead
                                        $vars[0] = 'lead';
                                        
                                        # encrypt the new version of parameters for leads
                                        $parameters = urlencode(Crypto::AESEncrypt(implode('|',$vars)));
                                        
                                        if(strpos($link,$sub) > -1)
                                        {
                                            $link = str_replace($sub,$sub . $parameters, $link);
                                        }
                                        else
                                        {
                                            $sub = strpos($link,'?') > -1 ? '&' . $sub : '?' . $sub;
                                            $link .= $sub . $parameters;
                                        }
                                    }
                     
                                    # redirect to the offer 
                                    Response::redirect($link); 
                                }
                            }
                        }
                    }
                }
            }
        }
    } 
}