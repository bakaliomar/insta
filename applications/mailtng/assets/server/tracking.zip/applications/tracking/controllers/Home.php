<?php namespace ma\applications\tracking\controllers
{
    if (!defined('MAILTNG_FMW')) die('<pre>It\'s forbidden to access these files directly , access should be only via index.php </pre>');
    /**
     * @framework       MailTng Framework 
     * @version         1.1
     * @author          MailTng Team
     * @copyright       Copyright (c) 2015 - 2016.	
     * @license		
     * @link	
     */
    use ma\mailtng\application\Controller as Controller;
    use ma\mailtng\application\Application as Application;
    use ma\mailtng\configuration\Configuration as Configuration;
    use ma\mailtng\http\Response as Response;
    use ma\mailtng\www\URL as URL;
    use ma\mailtng\www\Domains as Domains;
    use ma\mailtng\output\PrintWriter as PrintWriter;
    /**
     * @name            Home.controller 
     * @description     The Home controller
     * @package		ma\applications\redirect\controllers
     * @category        Controller
     * @author		MailTng Team			
     */
    class Home extends Controller 
    {
        /**
         * @name init
         * @description initializing proccess before the action method executed
         * @once
         * @protected
         */
        public function init() 
        {}

        /**
         * @name index
         * @description the index action
         * @before init
         * @after
         */
        public function index() 
        {
            # redirect to brand website
            if(strpos(file_get_contents(APPS_FOLDER. DS . Application::getPrefix() . DS . DEFAULT_CONFIGS_DIRECTORY . DS . 'domains.ini'),'=') > -1)
            {
                $configuration = new Configuration(array( "type" => "ini" ));
                $configuration = $configuration->initialize();
                $redirectConfig = $configuration->parse(APPS_FOLDER. DS . Application::getPrefix() . DS . DEFAULT_CONFIGS_DIRECTORY . DS . 'domains',false);
                $domain = Domains::getDomainFromURL($_SERVER['SERVER_NAME']);
                
                if(count($redirectConfig) && key_exists(str_replace('.','_',$domain),$redirectConfig))
                {
                    $folder = $redirectConfig[str_replace('.','_',$domain)];

                    if(file_exists(ROOT_PATH . DS . 'web' . DS . $folder))
                    {
                        Response::redirect(URL::getCurrentApplicationURL() . RDS . 'web' . RDS . $folder . RDS . 'index.html');
                    }
                }
            }

            PrintWriter::printValue('<center>Website is under construction !</center>');
        }
    } 
}