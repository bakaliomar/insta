<?php namespace ma\applications\tracking\controllers
{
    if (!defined('MAILTNG_FMW')) die('<pre>It\'s forbidden to access these files directly , access should be only via index.php </pre>');
    /**
     * @framework       MailTng Framework 
     * @version         1.1
     * @author          MailTng Team
     * @copyright       Copyright (c) 2015 - 2016.	
     * @license		
     * @link	
     */
    use ma\mailtng\application\Controller as Controller;
    use ma\mailtng\http\Request as Request;
    use ma\mailtng\http\Session as Session;
    use ma\mailtng\globals\Server as Server;
    use ma\mailtng\http\Client as Client;
    use ma\mailtng\encryption\Crypto as Crypto;
    use ma\mailtng\files\Paths as Paths;
    use ma\mailtng\types\Arrays as Arrays;
    /**
     * @name            Unsub.controller 
     * @description     The Unsub controller
     * @package		ma\applications\tracking\controllers
     * @category        Controller
     * @author		MailTng Team			
     */
    class Unsub extends Controller 
    {
        /**
         * @name index
         * @description the index action
         */
        public function index() 
        {
            # prevent master page
            $this->setShowMasterView(false);

            # retrieve all form data
            $formData = Request::getAllDataFromPOST();
            
            # execution case
            if(isset($formData) && count($formData))
            {
                $message = "Something went wrong !";
                $messageFlag = 'danger';
            
                $email = Request::getParameterFromPOST("email");
                $unsubMessage = Request::getParameterFromPOST("message");
                $meta = Request::getParameterFromPOST("meta");
                
                if(isset($email) && filter_var($email,FILTER_VALIDATE_EMAIL))
                {
                    $message = "Thank You ! You have been successfully removed from our subscribers list. You will no longer hear from us.";
                    $messageFlag = 'success';
                
                    # script file
                    $scriptFile = Paths::getCurrentApplicationRealPath() . DS . 'scripts' . DS . 'actions.php';

                    # get the client 
                    $agent = base64_encode(Server::get('HTTP_USER_AGENT'));
                    $ip = Client::getIp();
                    $language = strtoupper(substr(Server::get('HTTP_ACCEPT_LANGUAGE'), 0, 2));
                    $unsubMessage = ($unsubMessage != null && $unsubMessage != '') ? base64_encode($unsubMessage) : base64_encode('No Message !');

                    $parameters = Crypto::AESDecrypt($meta);
                    
                    if(!empty($parameters) && strpos($parameters,'|') > -1)
                    {
                        # encrypt the new version of parameters for leads
                        $parameters = Crypto::AESEncrypt('srv_unsub|' . $parameters);
                    }

                    # executing the script that handles redirection emails
                    exec("nohup php {$scriptFile} {$agent} {$ip} {$language} {$parameters} {$unsubMessage} &");
                }
                else
                {
                    $message = "Please check the email you have entered !";
                }
            }
            
            # check if there are some meta info 
            $metainfo = str_replace(' ','+',urldecode(Request::getParameterFromGET("m")));

            if(isset($metainfo))
            {
                $this->getPageView()->set('meta',$metainfo);
            }
            
            # add webpage name 
            $this->getPageView()->set('name',Arrays::getElement(explode('.',$_SERVER['SERVER_NAME']),0));
            
            # stores the message in the session 
            Session::set('proccess_message_flag',$messageFlag);
            Session::set('proccess_message',$message);

            # check if there is a message from a previous action
            $message = Session::getThenDel('proccess_message');

            if(isset($message))
            {
                # set the message into the template data system 
                $this->getPageView()->set('prev_action_message',$message);

                # message flag
                $messageFlag = Session::getThenDel('proccess_message_flag');
                $this->getPageView()->set('prev_action_message_flag',$messageFlag);
            }
        }
    } 
}