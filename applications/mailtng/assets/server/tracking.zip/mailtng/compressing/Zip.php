<?php namespace ma\mailtng\compressing
{
    if (!defined('MAILTNG_FMW')) die('<pre>It\'s forbidden to access these files directly , access should be only via index.php </pre>');
    /**
     * @framework       MailTng Framework 
     * @version         1.1
     * @author          MailTng Team
     * @copyright       Copyright (c) 2015 - 2016.	
     * @license		
     * @link	
     */
    use ma\mailtng\core\Base as Base;
    /**
     * @name            Zip.class 
     * @description     It's a class that deals with zipping / unzipping mechanism
     * @package		ma\mailtng\compressing
     * @category        Helper Class
     * @author		MailTng Team			
     */
    class Zip extends Base
    {
        /**
         * @name extract
         * @description extracts zip file into a specific directory
         * @access static
         * @param string $fileName
         * @param string $extractPath
         * @param bool
         * @return
         */
        public static function extract($fileName,$extractPath = '') 
       {
           $zip = new \ZipArchive;
           $res = $zip->open($fileName);
           if ($res === TRUE) 
           {
               $applicationConfiguration = Application::getCurrentApplicationPrefix('application');
               $uploadsFolder = is_array($applicationConfiguration) && key_exists('default-uploads-path',$applicationConfiguration) ? $applicationConfiguration['default-uploads-path'] : '';
               $extractPath = $extractPath === '' ? APPS_FOLDER. DS . Application::getCurrentApplicationPrefix() . DS  . $uploadsFolder :  $extractPath;
               $zip->extractTo($extractPath);
               $zip->close();
               return TRUE;
           } 
           else 
           {
               return FALSE;
           }
       }

       /**
         * @name getFileNames
         * @description gets the names of all the files in a specefic zip file
         * @access static
         * @param string $fileName
         * @param array
         * @return
         */
        public static function getFileNames($fileName) 
       {
           $names = array();
           $zip = new \ZipArchive;
           $res = $zip->open($fileName);
           if ($res === TRUE) 
           {
               for ($i = 0; $i < $zip->numFiles; $i++) 
               {
                   $names[] = $zip->getNameIndex($i);
               }
           } 
            return $names;
        }
    }
}